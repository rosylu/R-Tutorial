historyLength = 256
futureLength = 10
threshold = 5
column = 5
trainTestRatio = 0.2

dataPath = '/Users/cb.hsu/Documents/Project/mm_trade/data/TXF1-Minute-Trade.txt'

stopWin = 200
stopLost = 20
