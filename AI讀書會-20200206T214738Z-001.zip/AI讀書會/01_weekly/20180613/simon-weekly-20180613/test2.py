#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 12 11:40:52 2018

@author: mmlego
"""

import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import numpy as np


# method 1: subplot2grid
##########################
plt.figure()
ax1 = plt.subplot2grid((3, 3), (0, 0), colspan=3)  # stands for axes
ax1.plot([1, 2], [1, 2])
ax1.set_title('ax1_title')
ax2 = plt.subplot2grid((3, 3), (1, 0), colspan=2)
ax3 = plt.subplot2grid((3, 3), (1, 2), rowspan=2)
ax4 = plt.subplot2grid((3, 3), (2, 0))
ax4.scatter([1, 2], [2, 2])
ax4.set_xlabel('ax4_x')
ax4.set_ylabel('ax4_y')
ax5 = plt.subplot2grid((3, 3), (2, 1))

#: gridspec
#########################
f = plt.figure()
gs = gridspec.GridSpec(3, 3)
# use index from 0
ax6 = plt.subplot(gs[0, :])
ax7 = plt.subplot(gs[1, :2])
ax8 = plt.subplot(gs[1:, 2])
ax9 = plt.subplot(gs[2, 0])
ax10 = plt.subplot(gs[2, 1])
ax6.set_title('ax6')
ax7.set_title('ax7')
ax8.set_title('ax8')
ax9.set_title('ax9')
ax10.set_title('ax10')

a = np.arange(9).reshape(3,3)
print(a)

print(a[0, :])
print(a[1, :2])
print(a[1:, 2])
print(a[2, 0])
print(a[2, 1])
plt.subplots(sharex=True,sharey=True)