#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jun  3 12:47:58 2018

@author: mmlego
"""

# Import pandas as pd
import pandas as pd
import datetime as dt

# Import Date Time ,  Open ,  High   , Low ,Close , Volume
# from 2018/1/1 ~ 2018/3/7
#TXF1_1min = pd.read_csv('TXF1-1-Minute.csv',index_col=0)
TXF1_1min = pd.read_csv('TXF1-1-Minute.csv',parse_dates=['Date Time'])
#TXF1_1min = pd.read_csv('TXF1-1-Minute.csv',parse_dates=['timestamps'],names=['timestamps','open','high','low','close','volume'])

TXF1_1min.set_index('Date Time', inplace=True)


# Print out 
print(TXF1_1min)

print(TXF1_1min.Open)



#startdate = dt.date(2018, 2, 1)
enddate = dt.date(2018, 1, 5)



TXF1_1min = TXF1_1min.sort_index()
#rename index from 'Date Time' to 'DateTime'
#TXF1_1min.index.name = 'DateTime'
#TXF1_1min.columns = ['Open', 'High', 'Close', 'Low', 'Volume']
ohlc_dict = {'Open':'first','High':'max','Low':'min','Close':'last','Volume':'sum'}

TXF1_1min = TXF1_1min[TXF1_1min.index < enddate.strftime('%Y/%m/%d %H:%M:%S')]
print(TXF1_1min.Open)

#TXF1_5min = TXF1_1min.resample('15T',label='right',closed='right',how=ohlc_dict)
TXF1_5min = TXF1_1min.resample('21T',label='right',closed='right').agg({'Open':'first','High':'max','Low':'min','Close':'last','Volume':'sum'})


print(TXF1_5min.Open)
