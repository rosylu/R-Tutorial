library(randomForest)
set.seed(100)
train=read.table("train_data.csv", header=T, sep=",")
test=read.table("test_data.csv", header=T, sep=",")
ctrain=scan("ctrain.txt",what=character())
ctest=scan("ctest.txt",what=character())
train_data=cbind(ctrain,train)
test_data=cbind(ctest,test)
tree_model=randomForest(ctrain~.,data=train_data)
tree_predict=predict(tree_model,test_data,type="class")
k.result=tree_predict
TP=FP=TN=FN=0
for(i in 1: length(k.result)){
  if(k.result[i]=='L' && ctest[i] == 'L') TP=TP+1
  if(k.result[i]=='L' && ctest[i] == 'M') FP=FP+1
  if(k.result[i]=='M' && ctest[i] == 'L') FN=FN+1
  if(k.result[i]=='M' && ctest[i] == 'M') TN=TN+1
}
k.accuracy=(TP+TN)/ length(k.result)
k.accuracy

k.sen = TP/(TP+FN)
k.sen

k.spe = TN/(FP+TN)
k.spe

k.precision =TP/(TP+FP)
k.precision