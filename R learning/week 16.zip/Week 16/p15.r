library(e1071)
library(class)
y=Carseats
y$Sales = ifelse (Carseats$Sales >=8,"YES","NO")
y=y[,c(1:6,8)]
sd =apply(y[2:11],2,sd)
ave =apply(y[2:11],2,mean)
for (i in 1:nrow(y))
{
  for(j in 2:ncol(y))
  {
    
    y[i,j]=(y[i,j]-ave[(j-1)])/sd[(j-1)]
  }
}
set.seed(2)
train =sample(1:nrow(y),nrow(y)/2) 
test = -train
train_data=y[train,]
test_data=y[test,]
ctrain=as.factor(train_data[,1])
ctest=as.factor(test_data[,1])

tune.knn(train_data[,2:7],ctrain, k = 1:20) # best K = 9
k.result=knn(train_data[,2:7], test_data[,2:7],ctrain , k=18)
TP=FP=TN=FN=0
for(i in 1: length(k.result)){
  if(k.result[i]=='YES' && ctest[i] == 'YES') TP=TP+1
  if(k.result[i]=='YES' && ctest[i] == 'NO') FP=FP+1
  if(k.result[i]=='NO' && ctest[i] == 'YES') FN=FN+1
  if(k.result[i]=='NO' && ctest[i] == 'NO') TN=TN+1
}
k.accuracy=(TP+TN)/ length(k.result)
k.accuracy

k.sen = TP/(TP+FN)
k.sen

k.spe = TN/(FP+TN)
k.spe

k.precision =TP/(TP+FP)
k.precision
