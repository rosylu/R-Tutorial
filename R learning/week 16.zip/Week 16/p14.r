library(e1071)
library(class)
set.seed(2)
n=0.1*nrow(iris)
test.index=sample(1:nrow(iris),n)
iris.train=iris[-test.index,]
iris.test=iris[test.index,]

tune.knn(iris.train[,1:4],iris.train[,5], k = 1:5) 
k.result=knn(iris.train[,1:4], iris.test[,1:4],iris.train[,5] , k=4)